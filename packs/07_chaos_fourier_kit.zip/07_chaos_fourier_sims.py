"""Bonus: Double Pendulum RK4 & Discrete Fourier Transform (DFT) Visualizer."""
import numpy as np


def dft_epicycles(points_complex: np.ndarray) -> list[tuple[int, float, float]]:
    N = len(points_complex)
    coeffs = []
    for k in range(N):
        freq = k if k <= N // 2 else k - N
        c = np.sum(points_complex * np.exp(-2j * np.pi * freq * np.arange(N) / N)) / N
        coeffs.append((freq, float(np.abs(c)), float(np.angle(c))))
    coeffs.sort(key=lambda item: item[1], reverse=True)
    return coeffs


if __name__ == "__main__":
    t = np.linspace(0, 2 * np.pi, 64, endpoint=False)
    star = (1.0 + 0.35 * np.cos(5 * t)) * np.exp(1j * t)
    print("Top 5 modes:", [(f, round(a, 3)) for f, a, _ in dft_epicycles(star)[:5]])
